import java.util.*;

public class FloatingNumber {
    public static void main(String args[]){

      Scanner sc=new Scanner(System.in);
      System.out.print("\nInput First Number: ");
      Double a=sc.nextDouble();

      System.out.print("Input Second Number: ");
      Double b=sc.nextDouble();


    if (Math.round(a*1000) /1000.0  ==Math.round(b*1000)/1000.0)
    { 
         System.out.print("Both Numbers Are Equal");
    }
    else
    {
        System.out.print("Both Numbers Are Not Equal");
    }


  }
    
}
