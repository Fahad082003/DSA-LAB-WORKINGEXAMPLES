class SwapValues {
    int a;
    int b;

    SwapValues(int a, int b) 
    {
        this.a = a;
        this.b = b;
    }

    void swap() 
    {
        a = a + b;
        b = a - b;
        a = a - b;
    }

    void display() 
    {
        System.out.println("a: " + a);
        System.out.println("b: " + b);
    }

    public static void main(String[] args) 
    {
        SwapValues s1 = new SwapValues(5, 10);
        System.out.println("Before swapping:");
        s1.display();

        s1.swap();

        System.out.println("After swapping:");
        s1.display();
    }
}
