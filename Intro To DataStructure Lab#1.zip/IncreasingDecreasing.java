import java.util.*;

 
class IncreasingDecreasing{
    public static String Checking(int a,int b,int c)
    {

    if(b>a && c>b)
        {
           return "Increasing";
        }

    else if (b<a && c<b)
        {
           return "Decreasing";
        }

    else
        {
            return "Neither Increasing nor Decreasing";
        }

    }
public static void main(String args[])
    {
       
        Scanner sc=new Scanner(System.in);
        System.out.print("\nEnter First Number:");
        int a=sc.nextInt();
        System.out.print("Enter Second Number:");
        int b=sc.nextInt();
        System.out.print("Enter Third Number:");
        int c=sc.nextInt();
         
        String result=Checking(a, b, c);
        System.out.print("Given numbers are " +result);
         



    }

}