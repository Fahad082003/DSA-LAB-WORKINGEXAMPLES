/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Assignment0703;

import java.util.Scanner;


class Node {
    char data;
    Node prev, next;

    Node(char data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}


class DoublyLinkedList {
    private Node head;
    private Node tail;
    private Node cursor;

   
    public DoublyLinkedList() {
        this.head = null;
        this.tail = null;
        this.cursor = null;
    }

   
    public void insert(char data) {
        Node newNode = new Node(data);
        if (head == null) { 
            head = tail = cursor = newNode;
        } else if (cursor == null) { 
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
            cursor = newNode;
        } else { 
            newNode.next = cursor.next;
            newNode.prev = cursor;
            if (cursor.next != null) {
                cursor.next.prev = newNode;
            } else { 
                tail = newNode;
            }
            cursor.next = newNode;
            cursor = newNode;
        }
    }

    
    public void delete() {
        if (cursor == null) {
            System.out.println("Nothing to delete!");
            return;
        }
        if (cursor.prev != null) {
            cursor.prev.next = cursor.next;
        } else { 
            head = cursor.next;
        }
        if (cursor.next != null) {
            cursor.next.prev = cursor.prev;
        } else { 
            tail = cursor.prev;
        }
        cursor = cursor.prev;
    }


    public void moveCursorLeft() {
        if (cursor != null && cursor.prev != null) {
            cursor = cursor.prev;
        } else {
            System.out.println("Cursor is already at the beginning!");
        }
    }

   
    public void moveCursorRight() {
        if (cursor != null && cursor.next != null) {
            cursor = cursor.next;
        } else {
            System.out.println("Cursor is already at the end!");
        }
    }

  
    public void display() {
        Node temp = head;
        while (temp != null) {
            if (temp == cursor) {
                System.out.print("|");
            }
            System.out.print(temp.data);
            temp = temp.next;
        }
        if (cursor == null) {
            System.out.print("|");
        }
        System.out.println();
    }
}


public class TextEditor {
    public static void main(String[] args) {
        DoublyLinkedList editor = new DoublyLinkedList();
        Scanner scanner = new Scanner(System.in);
        String command;

        System.out.println("Text Editor Commands:");
        System.out.println("1. insert <char> - Insert a character");
        System.out.println("2. delete - Delete the character at the cursor");
        System.out.println("3. left - Move cursor left");
        System.out.println("4. right - Move cursor right");
        System.out.println("5. display - Display the text");
        System.out.println("6. exit - Exit the editor");

        while (true) {
            System.out.print("Enter command: ");
            command = scanner.nextLine();
            String[] parts = command.split(" ");

            switch (parts[0]) {
                case "insert":
                    if (parts.length > 1 && parts[1].length() == 1) {
                        editor.insert(parts[1].charAt(0));
                    } else {
                        System.out.println("Invalid insert command! Use: insert <char>");
                    }
                    break;
                case "delete":
                    editor.delete();
                    break;
                case "left":
                    editor.moveCursorLeft();
                    break;
                case "right":
                    editor.moveCursorRight();
                    break;
                case "display":
                    editor.display();
                    break;
                case "exit":
                    System.out.println("Exiting the editor. Goodbye!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid command!");
            }
        }
    }
}

