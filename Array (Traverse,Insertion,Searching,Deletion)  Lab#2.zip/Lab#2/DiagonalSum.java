import java.util.Scanner;
public class DiagonalSum {
    
    public static int rightDiagnol(int[][] numbers,int n)
    {
        int right_sum=0;
        for (int i=0; i<n; i++) 
        {
            for(int j=0; j<n; j++)
            {
               if(i+j==n-1)
               {
                right_sum +=numbers[i][j];
               }
            }
            
        }
        return right_sum;
    }
  
    public static int leftDiagnol(int[][] numbers,int n)
    {
        int left_sum=0;
        for (int i=0; i<n; i++) 
        {
         for(int j=0; j<n; j++)
          {
            if(i==j)
            {
                left_sum+=numbers[i][j];
            }
          }

        }
        return left_sum;
    }

       public static void main(String[] args) 
    {
        
        Scanner sc = new Scanner(System.in);

       
        System.out.println("\nEnter the value of n:");
        int n = sc.nextInt();
        int[][] numbers = new int[n][n];
        System.out.println("\nEnter the numbers for the array:");


        
        for (int i = 0; i<n; i++) 
        {
            for (int j = 0; j<n; j++) 
            {
                numbers[i][j] = sc.nextInt();
            }
        }


            int left_sum= leftDiagnol(numbers,n);
            int right_sum= rightDiagnol(numbers,n);
            
            System.out.print("Sum of Right Diagnol is " + right_sum);   
            System.out.print("\nSum of Left Diagnol is " + left_sum);  
    
    
    
    }
}
