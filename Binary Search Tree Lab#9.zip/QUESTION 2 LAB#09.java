class TreeNode {
    int value;
    TreeNode left, right;

    TreeNode(int item) {
        value = item;
        left = right = null;
    }
}

public class SortedArrayToBST {

    public static TreeNode sortedArrayToBST(int[] arr) {
        return sortedArrayToBSTHelper(arr, 0, arr.length - 1);
    }

    private static TreeNode sortedArrayToBSTHelper(int[] arr, int start, int end) {
        if (start > end) {
            return null;
        }

        int mid = (start + end) / 2; // Find the middle element
        TreeNode node = new TreeNode(arr[mid]); // Create a new node

        node.left = sortedArrayToBSTHelper(arr, start, mid - 1); // Left half
        node.right = sortedArrayToBSTHelper(arr, mid + 1, end); // Right half

        return node;
    }

    public static void inOrderTraversal(TreeNode node) {
        if (node != null) {
            inOrderTraversal(node.left);
            System.out.print(node.value + " ");
            inOrderTraversal(node.right);
        }
    }

    public static void main(String[] args) {
        int[] arr = {-10, -3, 0, 5, 9};

        TreeNode root = sortedArrayToBST(arr);

        System.out.println("In-order traversal of the constructed BST:");
        inOrderTraversal(root); // This should print the array in sorted order
    }
}
