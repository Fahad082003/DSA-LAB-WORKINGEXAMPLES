class Node {
    int data;
    Node left, right;

    Node(int data) {
        this.data = data;
        left = right = null;
    }
}

public class BinaryTreeToBST {
    static int index = 0;

    
    public static void inorderTraversal(Node root, ArrayList<Integer> list) {
        if (root == null) {
            return;
        }
        inorderTraversal(root.left, list);
        list.add(root.data);
        inorderTraversal(root.right, list);
    }

   
    public static void sortedListToBST(Node root, ArrayList<Integer> list) {
        if (root == null) {
            return;
        }
        sortedListToBST(root.left, list);
        root.data = list.get(index++);
        sortedListToBST(root.right, list);
    }

   
    public static Node binaryTreeToBST(Node root) {
        ArrayList<Integer> list = new ArrayList<>();
        inorderTraversal(root, list); 
        Collections.sort(list); 
        index = 0;
        sortedListToBST(root, list); 
        return root;
    }

    public static void inorderPrint(Node root) {
        if (root == null) {
            return;
        }
        inorderPrint(root.left);
        System.out.print(root.data + " ");
        inorderPrint(root.right);
    }

    public static void main(String[] args) {
        Node root = new Node(10);
        root.left = new Node(30);
        root.right = new Node(15);
        root.left.left = new Node(20);
        root.left.right = new Node(5);

        System.out.println("Inorder traversal of the original Binary Tree:");
        inorderPrint(root);

        root = binaryTreeToBST(root);

        System.out.println("\nInorder traversal of the converted Binary Search Tree:");
        inorderPrint(root);
    }
}
