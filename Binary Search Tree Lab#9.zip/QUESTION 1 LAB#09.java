// Design a binary expression tree representation of the following arithmetic expression.
//((5+2)*(2-1))/(2+9)
//Create a function for the traversal of the expression tree. 

class TreeNode {
    String value;
    TreeNode left, right;

    TreeNode(String item) {
        value = item;
        left = right = null;
    }
}

public class ExpressionTree {
    public static void preOrderTraversal(TreeNode node) {
        if (node != null) {
            System.out.print(node.value + " ");
            preOrderTraversal(node.left);
            preOrderTraversal(node.right);
        }
    }

    public static void inOrderTraversal(TreeNode node) {
        if (node != null) {
            inOrderTraversal(node.left);
            System.out.print(node.value + " ");
            inOrderTraversal(node.right);
        }
    }

    public static void postOrderTraversal(TreeNode node) {
        if (node != null) {
            postOrderTraversal(node.left);
            postOrderTraversal(node.right);
            System.out.print(node.value + " ");
        }
    }

    public static TreeNode constructExpressionTree() {
        TreeNode root = new TreeNode("/");

        root.left = new TreeNode("*");
        root.right = new TreeNode("+");

        root.left.left = new TreeNode("+");
        root.left.left.left = new TreeNode("5");
        root.left.left.right = new TreeNode("2");

        root.left.right = new TreeNode("-");
        root.left.right.left = new TreeNode("2");
        root.left.right.right = new TreeNode("1");

        root.right.left = new TreeNode("2");
        root.right.right = new TreeNode("9");

        return root;
    }

    public static void main(String[] args) {
        TreeNode root = constructExpressionTree();

        System.out.println("Pre-order traversal:");
        preOrderTraversal(root);

        System.out.println("\nIn-order traversal:");
        inOrderTraversal(root);

        System.out.println("\nPost-order traversal:");
        postOrderTraversal(root);
    }
}
