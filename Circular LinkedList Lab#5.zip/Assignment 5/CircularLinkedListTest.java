/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Assignment0703;


class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    private Node last;

    // Constructor
    public CircularLinkedList() {
        last = null;
    }

    // Insert a node at the end
    public void insert(int data) {
        Node newNode = new Node(data);
        if (last == null) { 
            last = newNode;
            last.next = last; 
        } else {
            newNode.next = last.next;
            last.next = newNode;
            last = newNode;
        }
    }

    public void deleteAtPosition(int position) {
        if (last == null) { 
            System.out.println("List is empty. Nothing to delete.");
            return;
        }

       
        int size = getSize();
        if (position < 1 || position > size) {
            System.out.println("Invalid position! Must be between 1 and " + size);
            return;
        }

       
        if (last.next == last && position == 1) {
            last = null;
            return;
        }

        Node current = last.next; 
        Node previous = last;

       
        if (position == 1) {
            previous.next = current.next;
            last.next = current.next;
            return;
        }

        for (int i = 1; i < position; i++) {
            previous = current;
            current = current.next;
        }

   
        previous.next = current.next;

        if (current == last) {
            last = previous;
        }
    }

    public void display() {
        if (last == null) {
            System.out.println("List is empty.");
            return;
        }
        Node temp = last.next;
        do {
            System.out.print(temp.data + " ");
            temp = temp.next;
        } while (temp != last.next);
        System.out.println();
    }

   
    private int getSize() {
        if (last == null) return 0;
        int count = 0;
        Node temp = last.next;
        do {
            count++;
            temp = temp.next;
        } while (temp != last.next);
        return count;
    }
}


public class CircularLinkedListTest {
    public static void main(String[] args) {
        CircularLinkedList cll = new CircularLinkedList();

        
        cll.insert(10);
        cll.insert(20);
        cll.insert(30);
        cll.insert(40);
        cll.insert(50);

        System.out.println("Original List:");
        cll.display();

      
        System.out.println("Deleting node at position 3:");
        cll.deleteAtPosition(3);
        cll.display();

        System.out.println("Deleting node at position 1:");
        cll.deleteAtPosition(1);
        cll.display();

        System.out.println("Deleting node at position 4:");
        cll.deleteAtPosition(4); 
        cll.display();

        System.out.println("Deleting node at position 2:");
        cll.deleteAtPosition(2);
        cll.display();
    }
}

